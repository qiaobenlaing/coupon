package com.batch.study.config;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.support.MapJobRegistry;
import org.springframework.batch.core.explore.JobExplorer;
import org.springframework.batch.core.explore.support.JobExplorerFactoryBean;
import org.springframework.batch.core.explore.support.SimpleJobExplorer;
import org.springframework.batch.core.launch.JobOperator;
import org.springframework.batch.core.launch.support.SimpleJobLauncher;
import org.springframework.batch.core.launch.support.SimpleJobOperator;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.resource.ListPreparedStatementSetter;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.mapping.PatternMatchingCompositeLineMapper;
import org.springframework.batch.item.file.transform.BeanWrapperFieldExtractor;
import org.springframework.batch.item.file.transform.DelimitedLineAggregator;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.FormatterLineAggregator;
import org.springframework.batch.item.file.transform.Range;
import org.springframework.batch.item.xml.StaxEventItemReader;
import org.springframework.batch.item.xml.StaxEventItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.PathResource;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.oxm.xstream.XStreamMarshaller;
import org.springframework.transaction.PlatformTransactionManager;

import com.batch.study.pojo.Goods;
import com.batch.study.pojo.Student;
import com.batch.study.processor.CsvItemProcessor;
import com.batch.study.processor.FixedLengthProcessor;
import com.batch.study.processor.JdbcProcessor;
import com.batch.study.processor.XMLProcessor;

@Configuration
//@EnableBatchProcessing
public class BatchConfiguration {

	@Value("${batch.jdbc.driver}")
	private String driverClassName;

	@Value("${batch.jdbc.url}")
	private String driverUrl;

	@Value("${batch.jdbc.user}")
	private String driverUsername;

	@Value("${batch.jdbc.password}")
	private String driverPassword;

	@Autowired
	@Qualifier("jobRepository")
	private JobRepository jobRepository;

	@Autowired
	private JobExplorer jobExplorer;
	
	
	@Bean
	public DataSource dataSource() {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setDriverClassName(driverClassName);
		dataSource.setUrl(driverUrl);
		dataSource.setUsername(driverUsername);
		dataSource.setPassword(driverPassword);
		return dataSource;
	}

	@Bean
	public SimpleJobLauncher jobLauncher() {
		SimpleJobLauncher jobLauncher = new SimpleJobLauncher();
		jobLauncher.setJobRepository(jobRepository);
		return jobLauncher;
	}

	@Bean
	public PlatformTransactionManager transactionManager() {
		return new DataSourceTransactionManager(dataSource());
	}
	
	@Bean
	public JobOperator jobOperator(){
		SimpleJobOperator jobOperator=new SimpleJobOperator();
		jobOperator.setJobRegistry(new MapJobRegistry());
		jobOperator.setJobRepository(jobRepository);
		jobOperator.setJobLauncher(jobLauncher());
		jobOperator.setJobExplorer(jobExplorer);
		
		return jobOperator;
	}
	/*以上代码不需要修改，倘若使用@EnableBatchProcessing注解，以下的相关bean配置可以不需要
	JobRepository - bean name "jobRepository"
	JobLauncher - bean name "jobLauncher"
	JobRegistry - bean name "jobRegistry"
	PlatformTransactionManager - bean name "transactionManager"
	JobBuilderFactory - bean name "jobBuilders"
	StepBuilderFactory - bean name "stepBuilders"
	*/
/****************************************************************************************/
	
	/**
	 * 文本文件读
	 * @return
	 */
	@Bean
	public FlatFileItemReader<Student> csvItemReader() {
		FlatFileItemReader<Student> csvItemReader = new FlatFileItemReader<Student>();
		csvItemReader.setResource(new PathResource("E:\\inputFile.csv"));
		csvItemReader.setStrict(false);
		csvItemReader.setLineMapper(new DefaultLineMapper<Student>() {
			{
				//DelimitedLineTokenizer为根据分隔符读取字段
				setLineTokenizer(new DelimitedLineTokenizer() {
					{
						setNames(new String[] { "id", "name", "age", "score" });
					}
				});
				//映射到相应的实体类
				setFieldSetMapper(new BeanWrapperFieldSetMapper<Student>() {
					{
						setTargetType(Student.class);
					}
				});
			}
		});
		return csvItemReader;
	}

	/**
	 * 处理操作，可以修改CsvItemProcessor，执行相应的操作
	 * @return
	 */
	@Bean
	public CsvItemProcessor processor() {
		return new CsvItemProcessor();
	}

	/*
	 * 文本文件写
	 */
	@Bean
	public FlatFileItemWriter<Student> csvItemWriter() {
		FlatFileItemWriter<Student> csvItemWriter = new FlatFileItemWriter<Student>();
		csvItemWriter.setResource(new PathResource("E:\\outputFile.csv") );
		
		csvItemWriter.setLineAggregator(new DelimitedLineAggregator<Student>() {
			{
				setDelimiter("    ");//设置分隔符
				//抽取相应的字段写入文件
				setFieldExtractor(new BeanWrapperFieldExtractor<Student>() {
					{
						setNames(new String[] { "name", "age", "score" });
					}
				});
			}
		});
		return csvItemWriter;
	}

	/**
	 * xml文件读
	 * @return
	 */
	@Bean
	public StaxEventItemReader<Goods> xmlItemReader() {
		StaxEventItemReader<Goods> xmlItemReader = new StaxEventItemReader<Goods>();
		xmlItemReader.setResource(new PathResource("E:\\input.xml"));
		xmlItemReader.setFragmentRootElementName("goods");
		xmlItemReader.setUnmarshaller(tradeMarshaller());

		return xmlItemReader;
	}

	
	/**
	 * 读写解析为同一个方法，只是需解析为实体类的不同，而相应修改
	 * @return
	 */
	@Bean
	public XStreamMarshaller tradeMarshaller() {
		XStreamMarshaller tradeMarshaller = new XStreamMarshaller();
		Map<String, Class<Goods>> map = new HashMap<String, Class<Goods>>();
		map.put("goods", Goods.class);
		tradeMarshaller.setAliases(map);
		return tradeMarshaller;
	}

	/**
	 * xml读取数据处理
	 * @return
	 */
	@Bean
	public XMLProcessor xmlItemProcessor() {
		return new XMLProcessor();
	}

	/**
	 * xml文件写，注意此处的RootTagName与读的FragmentRootElementName的区别
	 * @return
	 */
	@Bean
	public StaxEventItemWriter<Goods> xmlItemWriter() {
		StaxEventItemWriter<Goods> xmlItemWriter = new StaxEventItemWriter<Goods>();
		xmlItemWriter.setResource(new PathResource("E:\\output.xml"));
		xmlItemWriter.setRootTagName("wanggc");
		xmlItemWriter.setMarshaller(tradeMarshaller());

		return xmlItemWriter;
	}

	/**
	 * 文本文件，根据固定长度的读
	 * @return
	 */
	@Bean
	public FlatFileItemReader<Student> fixedLengthReader() {
		FlatFileItemReader<Student> fixedLengthReader = new FlatFileItemReader<Student>();
		fixedLengthReader.setStrict(false);
		fixedLengthReader.setResource(new PathResource("E:\\input.txt"));
		fixedLengthReader.setLineMapper(new DefaultLineMapper<Student>() {
			{
				setLineTokenizer(new FixedLengthTokenizer() {
					{
						setColumns(new Range[] { new Range(1, 6), new Range(7, 15), new Range(16, 18), new Range(19) });
						setNames(new String[] { "id", "name", "age", "score" });
					}
				});
				setFieldSetMapper(new BeanWrapperFieldSetMapper<Student>() {
					{
						setTargetType(Student.class);
					}
				});
			}
		});
		return fixedLengthReader;
	}

	/**
	 * 文本文件的处理
	 * @return
	 */
	@Bean
	public FixedLengthProcessor fixedLengthProcessor() {
		return new FixedLengthProcessor();
	}

	/**
	 * 文本文件，根据固定长度的写
	 * @return
	 */
	@Bean
	public FlatFileItemWriter<Student> fixedLengthWriter() {
		FlatFileItemWriter<Student> fixedLengthWriter = new FlatFileItemWriter<Student>();
		fixedLengthWriter.setResource(new PathResource("E:\\fixedLengthOutputFile.txt"));
		fixedLengthWriter.setLineAggregator(new FormatterLineAggregator<Student>() {
			{
				setFieldExtractor(new BeanWrapperFieldExtractor<Student>() {
					{
						setNames(new String[] { "id", "name", "age", "score" });
					}
				});
				//“-”为左对齐
				setFormat("%-9s%-20s%-3d%-2.0f");
			}
		});
		return fixedLengthWriter;
	}
	
	
	/**
	 * 数据库读
	 * @return
	 */
	@Bean
	public JdbcCursorItemReader<Student> jdbcItemReader() {
		JdbcCursorItemReader<Student> jdbcItemReader = new JdbcCursorItemReader<>();

		jdbcItemReader.setDataSource(dataSource());
		jdbcItemReader.setSql("SELECT `id`,`name`,`age`,`score` FROM `student` where id < ?");
		jdbcItemReader.setRowMapper(new BeanPropertyRowMapper<Student>() {
			{
				setMappedClass(Student.class);
			}
		});

		jdbcItemReader.setPreparedStatementSetter(new ListPreparedStatementSetter() {
			{
				List<String> list = new ArrayList<String>();
				list.add("3");
				setParameters(list);
			}
		});

		return jdbcItemReader;
	}

	@Bean
	public JdbcProcessor jdbcProcessor() {
		return new JdbcProcessor();
	}

	/**
	 * 数据库添加
	 * @return
	 */
	@Bean
	public JdbcBatchItemWriter<Student> jdbcItemWriter() {
		JdbcBatchItemWriter<Student> jdbcItemWriter = new JdbcBatchItemWriter<Student>();

		jdbcItemWriter.setDataSource(dataSource());
		jdbcItemWriter.setSql("insert into user (name,age,score) values (:name,:age,:score)");
		jdbcItemWriter.setItemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider());
		return jdbcItemWriter;
	}


}
