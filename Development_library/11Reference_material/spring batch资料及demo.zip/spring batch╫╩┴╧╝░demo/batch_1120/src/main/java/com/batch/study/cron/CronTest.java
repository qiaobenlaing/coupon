package com.batch.study.cron;

import java.util.UUID;

import javax.annotation.Resource;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

@Configuration
@EnableScheduling
public class CronTest {
	@Resource
	private JobLauncher launcher;
	@Resource
	private JobRepository jobRepository;
	@Resource
	private Job myJob;
	
	@Scheduled(cron="0/10 * * * * *")
	public void task1(){
		System.err.println("执行job");	
        try {
            JobExecution result = launcher.run(myJob, new JobParametersBuilder()
            		.addLong("time",System.currentTimeMillis()).toJobParameters());
            
            System.out.println(result.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
	}
}
